Wiring-theme
==========

[Wiring](http://wiring.org.co) IDE theme for the Arduino IDE.

Installation instructions at https://github.com/per1234/ino-themes.

![screenshot](https://github.com/per1234/ino-themes/raw/Wiring-theme/screenshot.jpg)
