processing-theme
==========

[Processing](http://processing.org/) 3 theme for the Arduino IDE.

Installation instructions at https://github.com/per1234/ino-themes.

![screenshot](https://github.com/per1234/ino-themes/raw/processing-theme/screenshot.jpg)
