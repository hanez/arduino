Arduino-retro
==========

The theme of the original Arduino IDE 003 updated for compatibility with modern versions.

Installation instructions at https://github.com/per1234/ino-themes.

![screenshot](https://github.com/per1234/ino-themes/raw/Arduino-retro/screenshot.jpg)
