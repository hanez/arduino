![screenshot](https://raw.githubusercontent.com/pilif-pilif/Arduino_theme/master/Screen.png)

Arduino Theme Dark 

\- \- \-

Locate your Folder e.g. for Linux `~/Applications/Arduino.app/Contents/Java/lib`, and `Program Files\Arduino\lib` on Windows. First back up the folder and then replace the content. You can also set  `editor.antialias=true in preferences.txt` 

\- \- \-
Based on https://github.com/technobly/MonokaiArduinoTheme and https://github.com/jeffThompson/DarkArduinoTheme 
